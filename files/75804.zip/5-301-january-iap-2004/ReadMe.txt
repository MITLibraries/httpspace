This zip package contains the HTML pages and files associated with the course. 

Some materials - such as videos, java applets, and other special content - are not posted on the OCW server, and are therefore not part of this package. This prevents zip packages from becoming too large for download. To download these resources to your computer, please read the FAQ at http://ocw.mit.edu/help/faq-technology/ .

Use of the materials in this package are governed by the same Creative Commons license as all other materials published on MIT OpenCourseWare. For more information, see http://ocw.mit.edu/terms .

If you have any trouble using this package, please contact us at ocw@mit.edu .